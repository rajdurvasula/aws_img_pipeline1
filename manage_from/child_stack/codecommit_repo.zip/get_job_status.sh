#!/bin/bash -xe
JOB_ID=$(cat /tmp/patch_job_id.txt)
IS_FAILED=$(curl -H "Authorization: Bearer $1" -H "Accept: application/json" -X GET "http://ip-10-0-0-96.ap-northeast-1.compute.internal/api/v2/jobs/$JOB_ID/job_host_summaries/" | jq -r '.results[0].failed')
if [[ "$IS_FAILED" == "false" ]]; then
exit 0
else
exit 1
fi
