#!/bin/bash -xe
HOST_IP=$(hostname -i)
ADD_HOST=$(curl -H "Authorization: Bearer $1" -H "Accept: application/json" -H "Content-Type: application/json" -X POST -d "{ \"name\": \"$HOST_IP\" }" "http://ip-10-0-0-96.ap-northeast-1.compute.internal/api/v2/inventories/13/hosts/" | jq -r '.id')
echo "$ADD_HOST" > /tmp/inventory_host.txt
