# create rdaddrbook app database
create database rdaddrbook;
# create application user
create user addrbook@localhost identified by 'rdaddrbook';
create user addrbook@'%' identified by 'rdaddrbook';
# grant privileges
grant all privileges on rdaddrbook.* to addrbook@'%' identified by 'rdaddrbook';
grant all privileges on rdaddrbook.* to addrbook@'localhost' identified by 'rdaddrbook';
flush privileges;

