#!/bin/bash -xe
JOB_ID=$(curl -H "Authorization: Bearer $1" -H "Accept: application/json" -H "Content-Type: application/json" -X POST -d "{ \"extra_vars\": { \"update_type\": \"security\" } }" "http://ip-10-0-0-96.ap-northeast-1.compute.internal/api/v2/job_templates/27/launch/" | jq -r '.job')
echo "$JOB_ID" > /tmp/patch_job_id.txt
