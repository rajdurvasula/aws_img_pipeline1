#!/bin/bash -xe
ADD_HOST=$(cat /tmp/inventory_host.txt)
curl -H "Authorization: Bearer $1" -H "Accept: application/json" -X DELETE "http://ip-10-0-0-96.ap-northeast-1.compute.internal/api/v2/inventories/$ADD_HOST/"
