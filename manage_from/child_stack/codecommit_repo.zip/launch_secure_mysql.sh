#!/bin/bash -xe
sed -i -e "s~ROOT_PASSWORD~$1~g" /tmp/secure_mysql.sh
/tmp/secure_mysql.sh
rm -f /tmp/secure_mysql.sh
